<?php include('server.php') ?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>RFID Signup</title>
	<link href='https://fonts.googleapis.com/css?family=Roboto+Slab:400,100,300,700|Lato:400,100,300,700,900' rel='stylesheet' type='text/css'>
	<link rel="stylesheet" href="css/animate.css">
	<link rel="stylesheet" href="css/style.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.4/jquery.min.js"></script>
</head>
<body>
<form method="post" action="login2.php">
	<div class="container">
		<div class="top">
			<h1 id="title" class="hidden"><span id="logo">Signup  <span>Form</span></span></h1>
		</div>
		<div class="login-box animated fadeInUp">
			<div class="box-header">
				<h2>Sign UP</h2>
			</div>
			<form method="post" action="register2.php">
				<?php include('errors.php'); ?>
					<label>Username</label><br/>
					<input type="text" name="username" value="<?php echo $username; ?>"><br/>				
					<label>Password</label><br/>
					<input type="password" name="password_1"><br/>
					<label>Confirm password</label><br/>
					<input type="password" name="password_2"><br/>
					<button type="submit" class="btn" name="reg_user">Register</button><br/>
					<a href="login.php"><p class="small"> Already a User? Login</p></a><br/>
			</form>
		</div>
	</div></form>
</body>
<script>
	$(document).ready(function () {
    	$('#logo').addClass('animated fadeInDown');
    	$("input:text:visible:first").focus();
	});
	$('#username').focus(function() {
		$('label[for="username"]').addClass('selected');
	});
	$('#username').blur(function() {
		$('label[for="username"]').removeClass('selected');
	});
	$('#password').focus(function() {
		$('label[for="password"]').addClass('selected');
	});
	$('#password').blur(function() {
		$('label[for="password"]').removeClass('selected');
	});
</script>
</html>