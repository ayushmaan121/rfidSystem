<?php include('server.php') ?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>RFID Tag Regiser</title>
	<link href='https://fonts.googleapis.com/css?family=Roboto+Slab:400,100,300,700|Lato:400,100,300,700,900' rel='stylesheet' type='text/css'>
	<link rel="stylesheet" href="css/animate.css">
	<link rel="stylesheet" href="css/style.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.4/jquery.min.js"></script>
</head>
<body>
<form method="post" action="login2.php">
	<div class="container">
		<div class="top">
			<h1 id="title" class="hidden"><span id="logo"> New Tag <span>Registration</span></span></h1>
		</div>
		<div class="login-box animated fadeInUp">
			<div class="box-header">
				<h2>Tag Registeration</h2>
			</div>
			<form method="post" action="tagregister.php">
				<?php include('errors.php'); ?>
				    <p>user : <?php  if (isset($_SESSION['username'])) : ?><?php echo $_SESSION['username']; ?></p><?php endif ?>
				    <label>Tagname</label><br/>
					<input type="text" name="tagname" value="<?php echo $tagname; ?>"><br/>				
					<label>Tag Number</label><br/>
					<input type="tagnumber" name="tagnumber_1"><br/>
					<label>Confirm Tag Number</label><br/>
					<input type="tagnumber" name="tagnumber_2"><br/>
					<button type="submit" class="btn" name="tagreg_user">Register this tag</button><br/>
					<a href="index2.php"><p class="small">Go back to Home?</p></a><br/>
			</form>
		</div>
	</div></form>
</body>
<script>
	$(document).ready(function () {
    	$('#logo').addClass('animated fadeInDown');
    	$("input:text:visible:first").focus();
	});
	$('#username').focus(function() {
		$('label[for="username"]').addClass('selected');
	});
	$('#username').blur(function() {
		$('label[for="username"]').removeClass('selected');
	});
	$('#password').focus(function() {
		$('label[for="password"]').addClass('selected');
	});
	$('#password').blur(function() {
		$('label[for="password"]').removeClass('selected');
	});
</script>
</html>