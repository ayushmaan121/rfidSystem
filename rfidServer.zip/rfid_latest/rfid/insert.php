<?php
if (isset($_GET['tag'])) {
    $tag = $_GET['tag'];
    $dbusername = "id5450395_rfid_tag"; 
    $dbpassword = "rfid_tag";  
    $server = "localhost"; 
    $dbname = "id5450395_rfid_tag";
    $stamp = date("Y-m-d");
    $dbconnect = mysqli_connect($server, $dbusername, $dbpassword, $dbname);
    $query = "SELECT * FROM rfid_details WHERE registered_rfid="."'$tag'";
    $result = mysqli_query($dbconnect,$query);
    //echo $result;
    $row = mysqli_fetch_assoc($result);
    $username = $row["username"];
    if($username== ""){
        echo "empty";
        $result1 = mysqli_query($dbconnect,"INSERT INTO rfid_unregistered(unregistered_tag) VALUES('$tag')");
    }
    else{
        echo "not empty";
        $tag_name= $row["tag_name"];
        $result1 = mysqli_query($dbconnect,"INSERT INTO rfid_data(username, tag_name, date) VALUES('$username','$tag_name','$stamp')");
    }
}
?>